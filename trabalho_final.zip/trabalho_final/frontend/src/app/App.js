import React from 'react'
import ListPage from './pages/ListPage'

function App() {
	return (
		<ListPage />
	)
}

export default App